module.exports = {
    API:"http://192.168.0.15:4000/"   
}

    


